package com.example.modeltest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;

import com.example.model.Product;

public class ProductTest {

	private Product product;

    @Before
    void setUp() {
        product = new Product(1, "Laptop", "High-end gaming laptop", 1200.50);
    }

    @Test
    void testProductConstructorWithAllFields() {
        assertEquals(1, product.getProductId());
        assertEquals("Laptop", product.getName());
        assertEquals("High-end gaming laptop", product.getDescription());
        assertEquals(1200.50, product.getPrice(), 0.001);
    }

    @Test
    void testProductConstructorWithNameAndPrice() {
        Product product2 = new Product(2, "Mouse", 25.99);
        assertEquals(2, product2.getProductId());
        assertEquals("Mouse", product2.getName());
        assertEquals(25.99, product2.getPrice(), 0.001);
    }

    @Test
    void testSetters() {
        product.setProductId(10);
        product.setName("Tablet");
        product.setDescription("Android tablet");
        product.setPrice(299.99);

        assertEquals(10, product.getProductId());
        assertEquals("Tablet", product.getName());
        assertEquals("Android tablet", product.getDescription());
        assertEquals(299.99, product.getPrice(), 0.001);
    }

    @Test
    void testEmptyConstructor() {
        Product emptyProduct = new Product();
        assertEquals(0, emptyProduct.getProductId());
        assertNull(emptyProduct.getName());
        assertNull(emptyProduct.getDescription());
        assertEquals(0.0, emptyProduct.getPrice(), 0.001);
    }
}
